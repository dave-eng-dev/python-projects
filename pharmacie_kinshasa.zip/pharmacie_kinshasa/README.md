# Gestion de Pharmacie — Kinshasa (version bêta)

Application desktop de gestion de pharmacie, développée en **Python + Tkinter**,
fonctionnant **100% hors-ligne** avec une base de données en fichiers **JSON**.

## Installation

1. Installer Python 3.9+ : https://www.python.org/downloads/
2. Aucune librairie externe n'est nécessaire (Tkinter est inclus avec Python).

## Lancer l'application

Depuis le dossier `pharmacie_kinshasa/` :

```
python main.py
```

## Comptes par défaut

| Identifiant | Mot de passe | Rôle         | Accès                                    |
|-------------|---------------|--------------|-------------------------------------------|
| admin       | admin123      | pharmacien   | Complet (médicaments, ventes, stats, utilisateurs) |
| stock       | stock123      | gestionnaire | Médicaments + ventes uniquement           |

⚠️ Pensez à changer ces mots de passe avant un usage réel
(modifiables via "Gestion des utilisateurs" une fois connecté en pharmacien,
ou directement dans `data/utilisateurs.json`).

## Structure du projet (MVC)

```
pharmacie_kinshasa/
├── main.py                    # Point d'entrée
├── data/                       # Base de données (3 fichiers JSON)
│   ├── medicaments.json
│   ├── utilisateurs.json
│   └── ventes.json
├── models/                     # Accès aux données + règles métier
│   ├── database.py
│   ├── medicament.py
│   ├── utilisateur.py
│   └── vente.py
├── controllers/                 # Pont entre les vues et les modèles
│   ├── auth_controller.py
│   ├── medicament_controller.py
│   ├── vente_controller.py
│   └── stats_controller.py
├── views/                       # Interface graphique (Tkinter)
│   ├── login_view.py
│   ├── dashboard_view.py
│   ├── medicament_view.py
│   ├── vente_view.py
│   ├── stats_view.py
│   └── utilisateur_view.py
├── utils/
│   └── facture.py               # Génération et impression des factures
└── factures/                    # Créé automatiquement : historique des factures .txt
```

## Fonctionnalités de cette version bêta

- Connexion avec rôles (pharmacien / gestionnaire)
- Gestion des médicaments (ajout, modification, suppression, réapprovisionnement)
- Alertes automatiques : péremption proche/dépassée, stock critique
- Vente avec mise à jour automatique du stock
- Génération de facture (texte) + tentative d'impression automatique
- Statistiques : revenus jour/semaine/mois, top médicaments vendus
- Gestion des utilisateurs (réservée au pharmacien)

## Limitations connues (à améliorer après la bêta)

- Mots de passe stockés en texte brut dans le JSON (à chiffrer pour un usage en production)
- Facture en format texte simple (pas de PDF avec logo pour l'instant)
- Pas de gestion multi-pharmacie / multi-poste simultané
