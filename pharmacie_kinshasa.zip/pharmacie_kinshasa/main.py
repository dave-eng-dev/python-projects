"""
main.py
Point d'entrée de l'application de gestion de pharmacie.
Lance la fenêtre de connexion, puis bascule vers le tableau de bord
une fois l'utilisateur authentifié.

Pour démarrer l'application :
    python main.py
"""

from views.login_view import LoginView
from views.dashboard_view import DashboardView


def lancer_dashboard(utilisateur):
    """
    Appelée par LoginView après une connexion réussie.
    Ouvre le tableau de bord correspondant à l'utilisateur connecté.
    """
    DashboardView(utilisateur, on_logout=relancer_connexion).mainloop()


def relancer_connexion():
    """
    Appelée quand l'utilisateur clique sur "Déconnexion" dans le tableau de bord.
    Réaffiche la fenêtre de connexion.
    """
    LoginView(lancer_dashboard).mainloop()


if __name__ == "__main__":
    # Démarrage de l'application : on affiche d'abord la fenêtre de connexion
    LoginView(lancer_dashboard).mainloop()
