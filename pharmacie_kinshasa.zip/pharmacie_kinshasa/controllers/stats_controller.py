"""
stats_controller.py
Calcule les statistiques affichées sur le tableau de bord :
revenus, médicaments les plus vendus, stocks critiques, alertes de péremption.
"""

from models.vente import VenteModel
from models.medicament import MedicamentModel


class StatsController:

    @staticmethod
    def revenu_jour():
        return VenteModel.revenus_par_periode(1)

    @staticmethod
    def revenu_semaine():
        return VenteModel.revenus_par_periode(7)

    @staticmethod
    def revenu_mois():
        return VenteModel.revenus_par_periode(30)

    @staticmethod
    def top_medicaments_vendus(top=5):
        return VenteModel.medicaments_les_plus_vendus(top)

    @staticmethod
    def stocks_critiques():
        return MedicamentModel.stock_critique()

    @staticmethod
    def alertes_peremption():
        return MedicamentModel.medicaments_perimes_ou_proches()

    @staticmethod
    def nombre_ventes_total():
        return len(VenteModel.lister())

    @staticmethod
    def nombre_medicaments_references():
        return len(MedicamentModel.lister())
