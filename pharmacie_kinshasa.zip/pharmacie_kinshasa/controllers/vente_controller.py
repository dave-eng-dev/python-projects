"""
vente_controller.py
Fait le lien entre la vue de vente et le modèle Vente.
"""

from models.vente import VenteModel


class VenteController:

    @staticmethod
    def enregistrer_vente(lignes, vendeur):
        if not lignes:
            raise ValueError("Aucun médicament sélectionné pour la vente.")
        return VenteModel.enregistrer_vente(lignes, vendeur)

    @staticmethod
    def lister_ventes():
        return VenteModel.lister()
