"""
medicament_controller.py
Fait le lien entre les vues (médicaments, stock) et le modèle Medicament.
"""

from models.medicament import MedicamentModel


class MedicamentController:

    @staticmethod
    def lister():
        return MedicamentModel.lister()

    @staticmethod
    def ajouter(nom, dosage, quantite, prix_unitaire, date_peremption, fournisseur):
        if not nom or not dosage:
            raise ValueError("Le nom et le dosage sont obligatoires.")
        try:
            quantite = int(quantite)
            prix_unitaire = float(prix_unitaire)
        except ValueError:
            raise ValueError("La quantité et le prix doivent être des nombres valides.")
        if quantite < 0 or prix_unitaire < 0:
            raise ValueError("La quantité et le prix ne peuvent pas être négatifs.")
        return MedicamentModel.ajouter(nom, dosage, quantite, prix_unitaire, date_peremption, fournisseur)

    @staticmethod
    def modifier(id_medicament, **champs):
        return MedicamentModel.modifier(id_medicament, **champs)

    @staticmethod
    def supprimer(id_medicament):
        MedicamentModel.supprimer(id_medicament)

    @staticmethod
    def reapprovisionner(id_medicament, quantite_ajoutee):
        return MedicamentModel.ajuster_quantite(id_medicament, int(quantite_ajoutee))

    @staticmethod
    def alertes_peremption():
        return MedicamentModel.medicaments_perimes_ou_proches()

    @staticmethod
    def alertes_stock_critique():
        return MedicamentModel.stock_critique()
