"""
auth_controller.py
Fait le lien entre la vue de connexion et le modèle Utilisateur.
"""

from models.utilisateur import UtilisateurModel


class AuthController:

    @staticmethod
    def connecter(nom_utilisateur, mot_de_passe):
        return UtilisateurModel.authentifier(nom_utilisateur, mot_de_passe)

    @staticmethod
    def creer_utilisateur(nom_utilisateur, mot_de_passe, role, nom_complet):
        return UtilisateurModel.ajouter(nom_utilisateur, mot_de_passe, role, nom_complet)

    @staticmethod
    def lister_utilisateurs():
        return UtilisateurModel.lister()

    @staticmethod
    def supprimer_utilisateur(id_utilisateur):
        UtilisateurModel.supprimer(id_utilisateur)
