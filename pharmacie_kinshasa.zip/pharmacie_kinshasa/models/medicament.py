"""
medicament.py
Modèle représentant un médicament et les opérations sur le stock.
"""

from datetime import datetime, timedelta
from models import database

FICHIER = "medicaments.json"

# Nombre de jours avant péremption à partir duquel une alerte est déclenchée
SEUIL_ALERTE_JOURS = 60
# Seuil de quantité en dessous duquel le stock est considéré "critique"
SEUIL_STOCK_CRITIQUE = 10


class Medicament:
    def __init__(self, id, nom, dosage, quantite, prix_unitaire,
                 date_peremption, fournisseur):
        self.id = id
        self.nom = nom
        self.dosage = dosage
        self.quantite = quantite
        self.prix_unitaire = prix_unitaire
        self.date_peremption = date_peremption  # format "YYYY-MM-DD"
        self.fournisseur = fournisseur

    def to_dict(self):
        return self.__dict__

    @staticmethod
    def from_dict(d):
        return Medicament(
            d["id"], d["nom"], d["dosage"], d["quantite"],
            d["prix_unitaire"], d["date_peremption"], d["fournisseur"]
        )


class MedicamentModel:
    """Gère la persistance et les règles métier liées aux médicaments."""

    @staticmethod
    def lister():
        return database.charger(FICHIER)

    @staticmethod
    def trouver_par_id(id_medicament):
        for m in MedicamentModel.lister():
            if m["id"] == id_medicament:
                return m
        return None

    @staticmethod
    def ajouter(nom, dosage, quantite, prix_unitaire, date_peremption, fournisseur):
        medicaments = MedicamentModel.lister()
        nouvel_id = database.prochain_id(medicaments)
        medicament = Medicament(
            nouvel_id, nom, dosage, int(quantite), float(prix_unitaire),
            date_peremption, fournisseur
        )
        medicaments.append(medicament.to_dict())
        database.sauvegarder(FICHIER, medicaments)
        return medicament

    @staticmethod
    def modifier(id_medicament, **champs):
        medicaments = MedicamentModel.lister()
        for m in medicaments:
            if m["id"] == id_medicament:
                m.update(champs)
                database.sauvegarder(FICHIER, medicaments)
                return m
        return None

    @staticmethod
    def supprimer(id_medicament):
        medicaments = MedicamentModel.lister()
        medicaments = [m for m in medicaments if m["id"] != id_medicament]
        database.sauvegarder(FICHIER, medicaments)

    @staticmethod
    def ajuster_quantite(id_medicament, delta):
        """Ajoute (ou retire si delta négatif) une quantité au stock d'un médicament."""
        medicaments = MedicamentModel.lister()
        for m in medicaments:
            if m["id"] == id_medicament:
                m["quantite"] = max(0, m["quantite"] + delta)
                database.sauvegarder(FICHIER, medicaments)
                return m
        return None

    @staticmethod
    def medicaments_perimes_ou_proches(seuil_jours=SEUIL_ALERTE_JOURS):
        """Retourne la liste des médicaments déjà périmés ou qui périment bientôt."""
        aujourd_hui = datetime.now().date()
        resultats = []
        for m in MedicamentModel.lister():
            try:
                date_exp = datetime.strptime(m["date_peremption"], "%Y-%m-%d").date()
            except (ValueError, KeyError):
                continue
            jours_restants = (date_exp - aujourd_hui).days
            if jours_restants <= seuil_jours:
                m_copie = dict(m)
                m_copie["jours_restants"] = jours_restants
                m_copie["perime"] = jours_restants < 0
                resultats.append(m_copie)
        return sorted(resultats, key=lambda x: x["jours_restants"])

    @staticmethod
    def stock_critique(seuil=SEUIL_STOCK_CRITIQUE):
        """Retourne les médicaments dont la quantité est sous le seuil critique."""
        return [m for m in MedicamentModel.lister() if m["quantite"] <= seuil]
