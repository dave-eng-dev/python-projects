"""
utilisateur.py
Modèle de gestion des utilisateurs (pharmacien / gestionnaire de stock).
"""

from models import database

FICHIER = "utilisateurs.json"


class UtilisateurModel:

    @staticmethod
    def lister():
        return database.charger(FICHIER)

    @staticmethod
    def authentifier(nom_utilisateur, mot_de_passe):
        """Vérifie les identifiants. Retourne le dict utilisateur si valide, sinon None."""
        for u in UtilisateurModel.lister():
            if u["nom_utilisateur"] == nom_utilisateur and u["mot_de_passe"] == mot_de_passe:
                return u
        return None

    @staticmethod
    def ajouter(nom_utilisateur, mot_de_passe, role, nom_complet):
        utilisateurs = UtilisateurModel.lister()
        if any(u["nom_utilisateur"] == nom_utilisateur for u in utilisateurs):
            raise ValueError("Ce nom d'utilisateur existe déjà.")
        nouvel_id = database.prochain_id(utilisateurs)
        utilisateur = {
            "id": nouvel_id,
            "nom_utilisateur": nom_utilisateur,
            "mot_de_passe": mot_de_passe,
            "role": role,  # "pharmacien" ou "gestionnaire"
            "nom_complet": nom_complet,
        }
        utilisateurs.append(utilisateur)
        database.sauvegarder(FICHIER, utilisateurs)
        return utilisateur

    @staticmethod
    def supprimer(id_utilisateur):
        utilisateurs = UtilisateurModel.lister()
        utilisateurs = [u for u in utilisateurs if u["id"] != id_utilisateur]
        database.sauvegarder(FICHIER, utilisateurs)
