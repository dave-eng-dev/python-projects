"""
vente.py
Modèle de gestion des ventes. Chaque vente met à jour automatiquement le stock
du médicament concerné (sortie de stock).
"""

from models import database
from models.medicament import MedicamentModel

FICHIER = "ventes.json"


class VenteModel:

    @staticmethod
    def lister():
        return database.charger(FICHIER)

    @staticmethod
    def enregistrer_vente(lignes, vendeur):
        """
        lignes : liste de dicts {"id_medicament": int, "quantite": int}
        vendeur : nom_complet de l'utilisateur connecté
        Retourne la facture créée (dict), ou lève ValueError si stock insuffisant.
        """
        medicaments_concernes = []
        total = 0.0

        # Vérification préalable du stock disponible avant toute mise à jour
        for ligne in lignes:
            medicament = MedicamentModel.trouver_par_id(ligne["id_medicament"])
            if medicament is None:
                raise ValueError(f"Médicament introuvable (id {ligne['id_medicament']}).")
            if medicament["quantite"] < ligne["quantite"]:
                raise ValueError(
                    f"Stock insuffisant pour {medicament['nom']} "
                    f"(disponible : {medicament['quantite']}, demandé : {ligne['quantite']})."
                )
            sous_total = medicament["prix_unitaire"] * ligne["quantite"]
            total += sous_total
            medicaments_concernes.append({
                "id_medicament": medicament["id"],
                "nom": medicament["nom"],
                "dosage": medicament["dosage"],
                "quantite": ligne["quantite"],
                "prix_unitaire": medicament["prix_unitaire"],
                "sous_total": sous_total,
            })

        # Mise à jour du stock (sortie) une fois la vérification validée
        for ligne in lignes:
            MedicamentModel.ajuster_quantite(ligne["id_medicament"], -ligne["quantite"])

        ventes = VenteModel.lister()
        nouvel_id = database.prochain_id(ventes)
        facture = {
            "id": nouvel_id,
            "date": database.horodatage(),
            "vendeur": vendeur,
            "lignes": medicaments_concernes,
            "total": total,
        }
        ventes.append(facture)
        database.sauvegarder(FICHIER, ventes)
        return facture

    @staticmethod
    def revenus_par_periode(jours):
        """Calcule le total des revenus sur les N derniers jours."""
        from datetime import datetime, timedelta
        seuil = datetime.now() - timedelta(days=jours)
        total = 0.0
        for v in VenteModel.lister():
            try:
                date_vente = datetime.strptime(v["date"], "%Y-%m-%d %H:%M:%S")
            except (ValueError, KeyError):
                continue
            if date_vente >= seuil:
                total += v["total"]
        return total

    @staticmethod
    def medicaments_les_plus_vendus(top=5):
        """Retourne les médicaments les plus vendus (par quantité cumulée)."""
        cumul = {}
        for v in VenteModel.lister():
            for ligne in v["lignes"]:
                nom = ligne["nom"]
                cumul[nom] = cumul.get(nom, 0) + ligne["quantite"]
        tries = sorted(cumul.items(), key=lambda x: x[1], reverse=True)
        return tries[:top]
