"""
database.py
Module générique de lecture/écriture des fichiers JSON.
Sert de couche d'accès aux données pour tous les modèles (Medicament, Utilisateur, Vente).
"""

import json
import os
import shutil
from datetime import datetime

# Dossier racine "data" où sont stockés tous les fichiers JSON
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")


def _chemin(nom_fichier):
    return os.path.join(DATA_DIR, nom_fichier)


def charger(nom_fichier):
    """Charge et retourne le contenu d'un fichier JSON. Retourne [] si le fichier est vide/absent."""
    chemin = _chemin(nom_fichier)
    if not os.path.exists(chemin):
        return []
    try:
        with open(chemin, "r", encoding="utf-8") as f:
            contenu = f.read().strip()
            if not contenu:
                return []
            return json.loads(contenu)
    except (json.JSONDecodeError, OSError):
        # Fichier corrompu : on tente de restaurer depuis une sauvegarde si elle existe
        sauvegarde = chemin + ".bak"
        if os.path.exists(sauvegarde):
            with open(sauvegarde, "r", encoding="utf-8") as f:
                return json.load(f)
        return []


def sauvegarder(nom_fichier, donnees):
    """Sauvegarde les données dans le fichier JSON, avec une copie de sauvegarde .bak avant écriture."""
    chemin = _chemin(nom_fichier)
    os.makedirs(DATA_DIR, exist_ok=True)

    # Sauvegarde de sécurité avant d'écraser le fichier (évite la perte de données)
    if os.path.exists(chemin):
        try:
            shutil.copy(chemin, chemin + ".bak")
        except OSError:
            pass

    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(donnees, f, ensure_ascii=False, indent=2)


def prochain_id(liste):
    """Calcule le prochain identifiant numérique disponible pour une liste d'enregistrements."""
    if not liste:
        return 1
    return max(item.get("id", 0) for item in liste) + 1


def horodatage():
    """Retourne la date/heure actuelle au format ISO, utilisée pour les ventes et journaux."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
