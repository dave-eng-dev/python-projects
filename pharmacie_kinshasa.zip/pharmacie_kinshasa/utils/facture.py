"""
facture.py
Génère le texte d'une facture et permet de l'envoyer à l'imprimante (ou de la sauvegarder en .txt).
"""

import os
import platform
import subprocess

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FACTURES_DIR = os.path.join(BASE_DIR, "factures")

NOM_PHARMACIE = "PHARMACIE"
ADRESSE_PHARMACIE = "Kinshasa, RD Congo"


def generer_texte_facture(facture):
    """Construit le texte formaté d'une facture à partir du dict retourné par VenteModel."""
    largeur = 42
    lignes = []
    lignes.append(NOM_PHARMACIE.center(largeur))
    lignes.append(ADRESSE_PHARMACIE.center(largeur))
    lignes.append("-" * largeur)
    lignes.append(f"Facture N°: {facture['id']}")
    lignes.append(f"Date       : {facture['date']}")
    lignes.append(f"Vendeur    : {facture['vendeur']}")
    lignes.append("-" * largeur)
    lignes.append(f"{'Article':<18}{'Qté':>4}{'P.U.':>9}{'Total':>11}")
    lignes.append("-" * largeur)
    for l in facture["lignes"]:
        nom = f"{l['nom']} {l['dosage']}"[:18]
        lignes.append(
            f"{nom:<18}{l['quantite']:>4}{l['prix_unitaire']:>9.2f}{l['sous_total']:>11.2f}"
        )
    lignes.append("-" * largeur)
    lignes.append(f"{'TOTAL (FC) :':<31}{facture['total']:>11.2f}")
    lignes.append("=" * largeur)
    lignes.append("Merci de votre confiance !".center(largeur))
    return "\n".join(lignes)


def imprimer_facture(facture, dossier_sortie=None):
    """
    Sauvegarde la facture en fichier .txt et tente de l'envoyer à l'imprimante par défaut.
    Retourne le chemin du fichier généré.
    """
    texte = generer_texte_facture(facture)

    if dossier_sortie is None:
        dossier_sortie = FACTURES_DIR
    os.makedirs(dossier_sortie, exist_ok=True)
    chemin_fichier = os.path.join(dossier_sortie, f"facture_{facture['id']}.txt")

    with open(chemin_fichier, "w", encoding="utf-8") as f:
        f.write(texte)

    # Tentative d'impression selon le système d'exploitation (best effort, ne bloque jamais l'application)
    systeme = platform.system()
    try:
        if systeme == "Windows":
            os.startfile(chemin_fichier, "print")
        elif systeme == "Darwin":
            subprocess.run(["lp", chemin_fichier], check=False)
        else:  # Linux
            subprocess.run(["lp", chemin_fichier], check=False)
    except Exception:
        # Si aucune imprimante n'est configurée, le fichier reste disponible pour impression manuelle
        pass

    return chemin_fichier
