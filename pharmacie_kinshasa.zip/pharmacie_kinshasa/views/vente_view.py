"""
vente_view.py
Fenêtre de vente : sélection des médicaments, calcul du total,
enregistrement de la vente, génération et impression de la facture.
"""

import tkinter as tk
from tkinter import ttk, messagebox

from controllers.medicament_controller import MedicamentController
from controllers.vente_controller import VenteController
from utils import facture as facture_utils


class VenteView(tk.Toplevel):
    def __init__(self, parent, utilisateur, on_close=None):
        super().__init__(parent)
        self.utilisateur = utilisateur
        self.on_close = on_close
        self.panier = []  # liste de {"id_medicament", "nom", "quantite", "prix_unitaire"}
        self.title("Nouvelle vente")
        self.geometry("700x520")
        self.protocol("WM_DELETE_WINDOW", self._fermer)
        self._construire_interface()

    def _construire_interface(self):
        # Sélection d'un médicament à ajouter au panier
        cadre_ajout = tk.LabelFrame(self, text="Ajouter un médicament")
        cadre_ajout.pack(fill="x", padx=10, pady=10)

        tk.Label(cadre_ajout, text="Médicament :").grid(row=0, column=0, padx=5, pady=5)
        self.medicaments_disponibles = {
            f"{m['nom']} {m['dosage']} (stock: {m['quantite']})": m
            for m in MedicamentController.lister() if m["quantite"] > 0
        }
        self.combo_medicament = ttk.Combobox(
            cadre_ajout, values=list(self.medicaments_disponibles.keys()), width=40, state="readonly"
        )
        self.combo_medicament.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(cadre_ajout, text="Quantité :").grid(row=0, column=2, padx=5, pady=5)
        self.champ_quantite = ttk.Entry(cadre_ajout, width=6)
        self.champ_quantite.insert(0, "1")
        self.champ_quantite.grid(row=0, column=3, padx=5, pady=5)

        ttk.Button(cadre_ajout, text="Ajouter au panier", command=self._ajouter_au_panier).grid(
            row=0, column=4, padx=10, pady=5
        )

        # Panier
        colonnes = ("nom", "quantite", "prix_unitaire", "sous_total")
        self.tableau = ttk.Treeview(self, columns=colonnes, show="headings", height=12)
        for c, libelle in zip(colonnes, ["Médicament", "Quantité", "Prix unitaire", "Sous-total"]):
            self.tableau.heading(c, text=libelle)
        self.tableau.pack(fill="both", expand=True, padx=10, pady=10)

        bas = tk.Frame(self)
        bas.pack(fill="x", padx=10, pady=10)
        self.label_total = tk.Label(bas, text="Total : 0.00 FC", font=("Segoe UI", 13, "bold"))
        self.label_total.pack(side="left")
        ttk.Button(bas, text="🗑️ Retirer la ligne sélectionnée", command=self._retirer_ligne).pack(side="left", padx=10)
        ttk.Button(bas, text="✅ Valider la vente et imprimer", command=self._valider_vente).pack(side="right")

    def _ajouter_au_panier(self):
        cle = self.combo_medicament.get()
        if cle not in self.medicaments_disponibles:
            messagebox.showwarning("Sélection requise", "Veuillez choisir un médicament.")
            return
        try:
            quantite = int(self.champ_quantite.get())
            if quantite <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Erreur", "Quantité invalide.")
            return

        medicament = self.medicaments_disponibles[cle]
        if quantite > medicament["quantite"]:
            messagebox.showerror("Stock insuffisant", f"Stock disponible : {medicament['quantite']}.")
            return

        self.panier.append({
            "id_medicament": medicament["id"],
            "nom": f"{medicament['nom']} {medicament['dosage']}",
            "quantite": quantite,
            "prix_unitaire": medicament["prix_unitaire"],
        })
        self._rafraichir_tableau()

    def _rafraichir_tableau(self):
        self.tableau.delete(*self.tableau.get_children())
        total = 0.0
        for i, ligne in enumerate(self.panier):
            sous_total = ligne["quantite"] * ligne["prix_unitaire"]
            total += sous_total
            self.tableau.insert("", "end", iid=str(i), values=(
                ligne["nom"], ligne["quantite"], f"{ligne['prix_unitaire']:.2f}", f"{sous_total:.2f}"
            ))
        self.label_total.config(text=f"Total : {total:.2f} FC")

    def _retirer_ligne(self):
        selection = self.tableau.selection()
        if not selection:
            return
        index = int(selection[0])
        self.panier.pop(index)
        self._rafraichir_tableau()

    def _valider_vente(self):
        if not self.panier:
            messagebox.showinfo("Panier vide", "Ajoutez au moins un médicament avant de valider.")
            return
        lignes = [{"id_medicament": l["id_medicament"], "quantite": l["quantite"]} for l in self.panier]
        try:
            facture = VenteController.enregistrer_vente(lignes, self.utilisateur["nom_complet"])
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))
            return

        # Génère le fichier texte de la facture ET tente de l'envoyer à l'imprimante
        # par défaut du système (voir utils/facture.py). Le fichier reste disponible
        # même si aucune imprimante n'est connectée.
        chemin_fichier = facture_utils.imprimer_facture(facture)

        messagebox.showinfo(
            "Vente enregistrée",
            f"Vente N°{facture['id']} enregistrée.\nFacture : {chemin_fichier}"
        )
        self.panier = []
        self._rafraichir_tableau()
        self._fermer()

    def _fermer(self):
        if self.on_close:
            self.on_close()
        self.destroy()
