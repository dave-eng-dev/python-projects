"""
stats_view.py
Fenêtre affichant les statistiques de la pharmacie :
revenus (jour/semaine/mois), médicaments les plus vendus,
stock critique et alertes de péremption.
Réservée au rôle "pharmacien" (voir dashboard_view.py).
"""

import tkinter as tk
from tkinter import ttk

from controllers.stats_controller import StatsController


class StatsView(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Statistiques & alertes")
        self.geometry("560x520")
        self._construire_interface()

    def _construire_interface(self):
        # ---- Bloc revenus ----
        cadre_revenus = tk.LabelFrame(self, text="💰 Revenus", font=("Segoe UI", 10, "bold"))
        cadre_revenus.pack(fill="x", padx=15, pady=10)

        # On récupère les 3 totaux (jour / semaine / mois) via le contrôleur
        jour = StatsController.revenu_jour()
        semaine = StatsController.revenu_semaine()
        mois = StatsController.revenu_mois()

        for libelle, valeur in [("Aujourd'hui", jour), ("7 derniers jours", semaine), ("30 derniers jours", mois)]:
            ligne = tk.Frame(cadre_revenus)
            ligne.pack(fill="x", padx=10, pady=3)
            tk.Label(ligne, text=libelle, anchor="w", width=20).pack(side="left")
            tk.Label(ligne, text=f"{valeur:,.2f} FC", font=("Segoe UI", 10, "bold"), fg="#1e8449").pack(side="left")

        # ---- Bloc top médicaments vendus ----
        cadre_top = tk.LabelFrame(self, text="🏆 Médicaments les plus vendus", font=("Segoe UI", 10, "bold"))
        cadre_top.pack(fill="x", padx=15, pady=10)

        top = StatsController.top_medicaments(5)
        if not top:
            tk.Label(cadre_top, text="Aucune vente enregistrée pour le moment.").pack(padx=10, pady=8)
        else:
            for rang, (nom, quantite) in enumerate(top, start=1):
                tk.Label(cadre_top, text=f"{rang}. {nom} — {quantite} unité(s) vendues",
                         anchor="w").pack(fill="x", padx=10, pady=2)

        # ---- Bloc stock critique ----
        cadre_stock = tk.LabelFrame(self, text="📉 Stock critique", font=("Segoe UI", 10, "bold"))
        cadre_stock.pack(fill="both", expand=True, padx=15, pady=10)

        critiques = StatsController.stock_critique()
        if not critiques:
            tk.Label(cadre_stock, text="Aucun médicament en stock critique ✅", fg="#1e8449").pack(padx=10, pady=8)
        else:
            for m in critiques:
                tk.Label(cadre_stock, text=f"⚠️ {m['nom']} {m['dosage']} — {m['quantite']} restant(s)",
                         fg="#c0392b", anchor="w").pack(fill="x", padx=10, pady=2)

        # ---- Bloc péremption ----
        cadre_peremption = tk.LabelFrame(self, text="⏳ Péremption proche / dépassée", font=("Segoe UI", 10, "bold"))
        cadre_peremption.pack(fill="both", expand=True, padx=15, pady=10)

        perimes = StatsController.alertes_peremption()
        if not perimes:
            tk.Label(cadre_peremption, text="Aucune alerte de péremption ✅", fg="#1e8449").pack(padx=10, pady=8)
        else:
            for m in perimes:
                texte = (f"❌ {m['nom']} — périmé depuis {abs(m['jours_restants'])} jour(s)"
                         if m["perime"] else
                         f"⏳ {m['nom']} — expire dans {m['jours_restants']} jour(s)")
                couleur = "#c0392b" if m["perime"] else "#d35400"
                tk.Label(cadre_peremption, text=texte, fg=couleur, anchor="w").pack(fill="x", padx=10, pady=2)
