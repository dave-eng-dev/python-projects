"""
dashboard_view.py
Tableau de bord principal après connexion. Affiche les alertes et donne accès
aux différents modules selon le rôle de l'utilisateur connecté.
"""

import tkinter as tk
from tkinter import ttk

from controllers.medicament_controller import MedicamentController
from controllers.stats_controller import StatsController


class DashboardView(tk.Tk):
    def __init__(self, utilisateur, on_logout):
        super().__init__()
        self.utilisateur = utilisateur
        self.on_logout = on_logout
        self.title("Tableau de bord — Gestion de Pharmacie")
        self.geometry("780x560")
        self.configure(bg="#f4f6f8")
        self._construire_interface()

    def _construire_interface(self):
        # Barre supérieure
        haut = tk.Frame(self, bg="#1a5276", height=60)
        haut.pack(fill="x")
        tk.Label(
            haut, text=f"💊 Bienvenue, {self.utilisateur['nom_complet']} "
                       f"({self.utilisateur['role']})",
            font=("Segoe UI", 13, "bold"), bg="#1a5276", fg="white"
        ).pack(side="left", padx=20, pady=15)
        ttk.Button(haut, text="Déconnexion", command=self._deconnecter).pack(side="right", padx=20, pady=12)

        # Zone des boutons de navigation
        nav = tk.Frame(self, bg="#f4f6f8")
        nav.pack(pady=20)

        ttk.Button(nav, text="📦 Médicaments / Stock", width=28,
                   command=self._ouvrir_medicaments).grid(row=0, column=0, padx=10, pady=8)
        ttk.Button(nav, text="🧾 Nouvelle vente", width=28,
                   command=self._ouvrir_vente).grid(row=0, column=1, padx=10, pady=8)

        if self.utilisateur["role"] == "pharmacien":
            ttk.Button(nav, text="📊 Statistiques", width=28,
                       command=self._ouvrir_stats).grid(row=1, column=0, padx=10, pady=8)
            ttk.Button(nav, text="👥 Gestion des utilisateurs", width=28,
                       command=self._ouvrir_utilisateurs).grid(row=1, column=1, padx=10, pady=8)

        # Zone des alertes
        self.cadre_alertes = tk.LabelFrame(
            self, text="⚠️ Alertes", bg="#fdf2e9", font=("Segoe UI", 10, "bold"), padx=10, pady=10
        )
        self.cadre_alertes.pack(fill="both", expand=True, padx=20, pady=10)
        self._rafraichir_alertes()

    def _rafraichir_alertes(self):
        for w in self.cadre_alertes.winfo_children():
            w.destroy()

        perimes = MedicamentController.alertes_peremption()
        critiques = MedicamentController.alertes_stock_critique()

        zone_scroll = tk.Frame(self.cadre_alertes, bg="#fdf2e9")
        zone_scroll.pack(fill="both", expand=True)

        if not perimes and not critiques:
            tk.Label(zone_scroll, text="Aucune alerte. Tout va bien ✅",
                     bg="#fdf2e9", fg="#1e8449").pack(anchor="w")
            return

        for m in perimes:
            texte = (f"❌ {m['nom']} — PÉRIMÉ depuis {abs(m['jours_restants'])} jour(s)"
                     if m["perime"] else
                     f"⏳ {m['nom']} — péremption dans {m['jours_restants']} jour(s)")
            couleur = "#c0392b" if m["perime"] else "#d35400"
            tk.Label(zone_scroll, text=texte, bg="#fdf2e9", fg=couleur, anchor="w").pack(fill="x")

        for m in critiques:
            tk.Label(
                zone_scroll, text=f"📉 {m['nom']} — stock critique ({m['quantite']} restant(s))",
                bg="#fdf2e9", fg="#922b21", anchor="w"
            ).pack(fill="x")

    def _ouvrir_medicaments(self):
        from views.medicament_view import MedicamentView
        MedicamentView(self, self.utilisateur, on_close=self._rafraichir_alertes)

    def _ouvrir_vente(self):
        from views.vente_view import VenteView
        VenteView(self, self.utilisateur, on_close=self._rafraichir_alertes)

    def _ouvrir_stats(self):
        from views.stats_view import StatsView
        StatsView(self)

    def _ouvrir_utilisateurs(self):
        from views.utilisateur_view import UtilisateurView
        UtilisateurView(self)

    def _deconnecter(self):
        self.destroy()
        self.on_logout()
