"""
login_view.py
Fenêtre de connexion. Authentifie l'utilisateur puis ouvre le tableau de bord.
"""

import tkinter as tk
from tkinter import ttk, messagebox

from controllers.auth_controller import AuthController


class LoginView(tk.Tk):
    def __init__(self, on_login_success):
        super().__init__()
        self.on_login_success = on_login_success
        self.title("Connexion — Gestion de Pharmacie")
        self.geometry("420x320")
        self.resizable(False, False)
        self.configure(bg="#f4f6f8")
        self._construire_interface()

    def _construire_interface(self):
        cadre = tk.Frame(self, bg="#f4f6f8")
        cadre.pack(expand=True)

        tk.Label(
            cadre, text="💊 Gestion de Pharmacie",
            font=("Segoe UI", 18, "bold"), bg="#f4f6f8", fg="#1a5276"
        ).pack(pady=(30, 5))
        tk.Label(
            cadre, text="Kinshasa", font=("Segoe UI", 10), bg="#f4f6f8", fg="#566573"
        ).pack(pady=(0, 25))

        tk.Label(cadre, text="Nom d'utilisateur", bg="#f4f6f8").pack(anchor="w")
        self.champ_utilisateur = ttk.Entry(cadre, width=32)
        self.champ_utilisateur.pack(pady=(0, 10))
        self.champ_utilisateur.focus()

        tk.Label(cadre, text="Mot de passe", bg="#f4f6f8").pack(anchor="w")
        self.champ_mdp = ttk.Entry(cadre, width=32, show="*")
        self.champ_mdp.pack(pady=(0, 20))

        bouton = ttk.Button(cadre, text="Se connecter", command=self._connecter)
        bouton.pack(pady=5)
        self.bind("<Return>", lambda e: self._connecter())

        tk.Label(
            cadre, text="Comptes par défaut : admin/admin123 (pharmacien)\n"
                        "stock/stock123 (gestionnaire)",
            font=("Segoe UI", 8), bg="#f4f6f8", fg="#95a5a6", justify="center"
        ).pack(pady=(15, 0))

    def _connecter(self):
        nom = self.champ_utilisateur.get().strip()
        mdp = self.champ_mdp.get().strip()
        if not nom or not mdp:
            messagebox.showwarning("Champs manquants", "Veuillez remplir tous les champs.")
            return
        utilisateur = AuthController.connecter(nom, mdp)
        if utilisateur is None:
            messagebox.showerror("Échec de connexion", "Nom d'utilisateur ou mot de passe incorrect.")
            return
        self.destroy()
        self.on_login_success(utilisateur)
