"""
utilisateur_view.py
Fenêtre de gestion des comptes utilisateurs (ajout / suppression).
Réservée au rôle "pharmacien" (voir dashboard_view.py).
"""

import tkinter as tk
from tkinter import ttk, messagebox

from controllers.auth_controller import AuthController


class UtilisateurView(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Gestion des utilisateurs")
        self.geometry("500x420")
        self._construire_interface()
        self._rafraichir_liste()

    def _construire_interface(self):
        haut = tk.Frame(self)
        haut.pack(fill="x", padx=10, pady=10)
        ttk.Button(haut, text="➕ Ajouter un utilisateur", command=self._ouvrir_formulaire_ajout).pack(side="left")
        ttk.Button(haut, text="🗑️ Supprimer la sélection", command=self._supprimer_selection).pack(side="left", padx=5)

        colonnes = ("id", "nom_utilisateur", "nom_complet", "role")
        self.tableau = ttk.Treeview(self, columns=colonnes, show="headings", height=14)
        for c, libelle in zip(colonnes, ["ID", "Identifiant", "Nom complet", "Rôle"]):
            self.tableau.heading(c, text=libelle)
        self.tableau.pack(fill="both", expand=True, padx=10, pady=10)

    def _rafraichir_liste(self):
        self.tableau.delete(*self.tableau.get_children())
        for u in AuthController.lister_utilisateurs():
            # On n'affiche jamais le mot de passe dans le tableau, par sécurité minimale
            self.tableau.insert("", "end", iid=u["id"], values=(
                u["id"], u["nom_utilisateur"], u["nom_complet"], u["role"]
            ))

    def _ouvrir_formulaire_ajout(self):
        FormulaireUtilisateur(self, on_valide=self._rafraichir_liste)

    def _supprimer_selection(self):
        selection = self.tableau.selection()
        if not selection:
            messagebox.showinfo("Sélection requise", "Veuillez sélectionner un utilisateur.")
            return
        if messagebox.askyesno("Confirmation", "Supprimer définitivement ce compte ?"):
            AuthController.supprimer_utilisateur(int(selection[0]))
            self._rafraichir_liste()


class FormulaireUtilisateur(tk.Toplevel):
    """Petit formulaire pour créer un nouveau compte utilisateur."""

    def __init__(self, parent, on_valide=None):
        super().__init__(parent)
        self.on_valide = on_valide
        self.title("Ajouter un utilisateur")
        self.geometry("340x320")
        self._construire_interface()

    def _construire_interface(self):
        tk.Label(self, text="Nom complet").pack(anchor="w", padx=20, pady=(15, 0))
        self.champ_nom_complet = ttk.Entry(self, width=32)
        self.champ_nom_complet.pack(padx=20)

        tk.Label(self, text="Identifiant").pack(anchor="w", padx=20, pady=(10, 0))
        self.champ_identifiant = ttk.Entry(self, width=32)
        self.champ_identifiant.pack(padx=20)

        tk.Label(self, text="Mot de passe").pack(anchor="w", padx=20, pady=(10, 0))
        self.champ_mdp = ttk.Entry(self, width=32, show="*")
        self.champ_mdp.pack(padx=20)

        tk.Label(self, text="Rôle").pack(anchor="w", padx=20, pady=(10, 0))
        self.combo_role = ttk.Combobox(self, values=["pharmacien", "gestionnaire"], state="readonly", width=29)
        self.combo_role.set("gestionnaire")
        self.combo_role.pack(padx=20)

        ttk.Button(self, text="Créer le compte", command=self._valider).pack(pady=20)

    def _valider(self):
        nom_complet = self.champ_nom_complet.get().strip()
        identifiant = self.champ_identifiant.get().strip()
        mdp = self.champ_mdp.get().strip()
        role = self.combo_role.get()

        if not nom_complet or not identifiant or not mdp:
            messagebox.showerror("Champs manquants", "Tous les champs sont obligatoires.")
            return

        try:
            AuthController.creer_utilisateur(identifiant, mdp, role, nom_complet)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))
            return

        if self.on_valide:
            self.on_valide()
        self.destroy()
