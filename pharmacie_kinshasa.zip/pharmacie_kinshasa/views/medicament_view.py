"""
medicament_view.py
Fenêtre de gestion des médicaments : liste, ajout, modification,
suppression et réapprovisionnement du stock.
"""

import tkinter as tk
from tkinter import ttk, messagebox

from controllers.medicament_controller import MedicamentController


class MedicamentView(tk.Toplevel):
    def __init__(self, parent, utilisateur, on_close=None):
        super().__init__(parent)
        self.utilisateur = utilisateur
        self.on_close = on_close
        self.title("Médicaments / Stock")
        self.geometry("900x520")
        self.protocol("WM_DELETE_WINDOW", self._fermer)
        self._construire_interface()
        self._rafraichir_liste()

    def _construire_interface(self):
        haut = tk.Frame(self)
        haut.pack(fill="x", padx=10, pady=10)
        ttk.Button(haut, text="➕ Ajouter un médicament", command=self._ouvrir_formulaire_ajout).pack(side="left")
        ttk.Button(haut, text="✏️ Modifier", command=self._modifier_selection).pack(side="left", padx=5)
        ttk.Button(haut, text="➕ Réapprovisionner", command=self._reapprovisionner_selection).pack(side="left", padx=5)

        if self.utilisateur["role"] == "pharmacien":
            ttk.Button(haut, text="🗑️ Supprimer", command=self._supprimer_selection).pack(side="left", padx=5)

        colonnes = ("id", "nom", "dosage", "quantite", "prix", "peremption", "fournisseur")
        self.tableau = ttk.Treeview(self, columns=colonnes, show="headings", height=18)
        entetes = {
            "id": "ID", "nom": "Nom", "dosage": "Dosage", "quantite": "Quantité",
            "prix": "Prix (FC)", "peremption": "Péremption", "fournisseur": "Fournisseur"
        }
        for c in colonnes:
            self.tableau.heading(c, text=entetes[c])
            self.tableau.column(c, width=110 if c != "nom" else 150)
        self.tableau.pack(fill="both", expand=True, padx=10, pady=10)

    def _rafraichir_liste(self):
        self.tableau.delete(*self.tableau.get_children())
        for m in MedicamentController.lister():
            self.tableau.insert("", "end", iid=m["id"], values=(
                m["id"], m["nom"], m["dosage"], m["quantite"],
                f"{m['prix_unitaire']:.2f}", m["date_peremption"], m["fournisseur"]
            ))

    def _id_selectionne(self):
        selection = self.tableau.selection()
        if not selection:
            messagebox.showinfo("Sélection requise", "Veuillez sélectionner un médicament dans la liste.")
            return None
        return int(selection[0])

    def _ouvrir_formulaire_ajout(self):
        FormulaireMedicament(self, on_valide=self._rafraichir_liste)

    def _modifier_selection(self):
        id_med = self._id_selectionne()
        if id_med is None:
            return
        medicament = MedicamentController.lister()
        medicament = next(m for m in medicament if m["id"] == id_med)
        FormulaireMedicament(self, medicament=medicament, on_valide=self._rafraichir_liste)

    def _reapprovisionner_selection(self):
        id_med = self._id_selectionne()
        if id_med is None:
            return
        fenetre = tk.Toplevel(self)
        fenetre.title("Réapprovisionnement")
        fenetre.geometry("300x140")
        tk.Label(fenetre, text="Quantité à ajouter :").pack(pady=(15, 5))
        champ = ttk.Entry(fenetre, width=15)
        champ.pack()
        champ.focus()

        def valider():
            try:
                quantite = int(champ.get())
                if quantite <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Erreur", "Veuillez entrer un nombre entier positif.")
                return
            MedicamentController.reapprovisionner(id_med, quantite)
            fenetre.destroy()
            self._rafraichir_liste()

        ttk.Button(fenetre, text="Valider", command=valider).pack(pady=15)

    def _supprimer_selection(self):
        id_med = self._id_selectionne()
        if id_med is None:
            return
        if messagebox.askyesno("Confirmation", "Supprimer définitivement ce médicament ?"):
            MedicamentController.supprimer(id_med)
            self._rafraichir_liste()

    def _fermer(self):
        if self.on_close:
            self.on_close()
        self.destroy()


class FormulaireMedicament(tk.Toplevel):
    """Formulaire commun pour l'ajout et la modification d'un médicament."""

    def __init__(self, parent, medicament=None, on_valide=None):
        super().__init__(parent)
        self.medicament = medicament
        self.on_valide = on_valide
        self.title("Modifier le médicament" if medicament else "Ajouter un médicament")
        self.geometry("360x420")
        self._construire_interface()

    def _construire_interface(self):
        champs = [
            ("nom", "Nom"), ("dosage", "Dosage"), ("quantite", "Quantité"),
            ("prix_unitaire", "Prix unitaire (FC)"),
            ("date_peremption", "Péremption (AAAA-MM-JJ)"), ("fournisseur", "Fournisseur"),
        ]
        self.entrees = {}
        for cle, libelle in champs:
            tk.Label(self, text=libelle).pack(anchor="w", padx=20, pady=(10, 0))
            entree = ttk.Entry(self, width=35)
            entree.pack(padx=20)
            if self.medicament:
                entree.insert(0, str(self.medicament.get(cle, "")))
            self.entrees[cle] = entree

        ttk.Button(self, text="Enregistrer", command=self._valider).pack(pady=20)

    def _valider(self):
        valeurs = {cle: e.get().strip() for cle, e in self.entrees.items()}
        try:
            if self.medicament:
                MedicamentController.modifier(
                    self.medicament["id"],
                    nom=valeurs["nom"], dosage=valeurs["dosage"],
                    quantite=int(valeurs["quantite"]), prix_unitaire=float(valeurs["prix_unitaire"]),
                    date_peremption=valeurs["date_peremption"], fournisseur=valeurs["fournisseur"]
                )
            else:
                MedicamentController.ajouter(
                    valeurs["nom"], valeurs["dosage"], valeurs["quantite"],
                    valeurs["prix_unitaire"], valeurs["date_peremption"], valeurs["fournisseur"]
                )
        except ValueError as e:
            messagebox.showerror("Erreur de saisie", str(e))
            return
        if self.on_valide:
            self.on_valide()
        self.destroy()
